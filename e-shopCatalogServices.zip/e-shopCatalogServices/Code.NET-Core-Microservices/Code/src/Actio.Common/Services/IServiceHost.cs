namespace Actio.Common.Services
{
    public interface IServiceHost
    {
         void Run();
    }
}