﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using VaultWebAPI.Models;
using VaultWebAPI.VaultConfigurations;

namespace VaultWebAPI.Contexts
{
    public class TransactionContext : DbContext
    {
        public TransactionContext()
        {
        }

        public TransactionContext(DbContextOptions<TransactionContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            
            optionsBuilder.UseSqlServer(new VaultConfiguration().EFConnectionString());
        }
    }
}
