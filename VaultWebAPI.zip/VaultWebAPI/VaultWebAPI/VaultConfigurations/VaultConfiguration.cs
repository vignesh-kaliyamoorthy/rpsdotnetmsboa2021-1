﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VaultSharp;
using VaultSharp.V1.AuthMethods;
using VaultSharp.V1.AuthMethods.Token;

namespace VaultWebAPI.VaultConfigurations
{
    public class VaultConfiguration
    {
        //public static Dictionary<string,object> VaultData { get; set; }

        public String EFConnectionString()
        {
            Dictionary<String, Object> data = new VaultConfiguration().GetDBCredentials().Result;

            SqlConnectionStringBuilder providerCs = new SqlConnectionStringBuilder();
            providerCs.InitialCatalog = "RPSDB";
            providerCs.UserID = data["username"].ToString();
            providerCs.Password = data["password"].ToString();
            providerCs.DataSource = "DESKTOP-55AGI0I\\MSSQLEXPRESS2021";

            //providerCs.UserID = CryptoService2.Decrypt(ConfigurationManager.AppSettings["UserId"]);
            providerCs.MultipleActiveResultSets = true;
            providerCs.TrustServerCertificate = false;



            //ecsb.Provider = "System.Data.SqlClient";
            //ecsb.ProviderConnectionString = providerCs.ToString();

            //ecsb.Metadata = string.Format("res://{0}/EDModel.csdl|res://{0}/EDModel.ssdl|res://{0}/EDModel.msl", typeof(Entities).Assembly.FullName);

            return providerCs.ToString();

        }

        public async Task<Dictionary<string,object>> GetDBCredentials()
        {
            // Initialize one of the several auth methods.
            IAuthMethodInfo authMethod = new TokenAuthMethodInfo("s.dbWzzWKH2SxumihXafpopkCp");

            // Initialize settings. You can also set proxies, custom delegates etc. here.
            var vaultClientSettings = new VaultClientSettings("http://localhost:8200", authMethod);

            IVaultClient vaultClient = new VaultClient(vaultClientSettings);
            Console.WriteLine(vaultClient.V1.Secrets);
            //var dbcapability = await vaultClient.V1.System.GetCallingTokenCapabilitiesAsync("secret/jwt-secret");

            //var test = dbcapability.Data.Capabilities.GetEnumerator();
            //while (test.MoveNext())
            //{
            //    Console.WriteLine(test.Current);
            //}
            //MemberInfo[] memberInfo=vaultClient.V1.Secrets.KeyValue.GetType().GetMembers();
            //foreach(MemberInfo mem in memberInfo){
            //    Console.WriteLine(mem.Name);
            //}

            var result = await vaultClient.V1.Secrets.KeyValue.V1.ReadSecretAsync("mssqlsecret", "secret", null);

            return result.Data;

        }
    }
}
